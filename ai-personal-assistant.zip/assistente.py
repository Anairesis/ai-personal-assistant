import torch
import torchaudio
import sounddevice as sd
import numpy as np
import whisper
from TTS.api import TTS

# Silero VAD setup
model_vad, utils = torch.hub.load(repo_or_dir='snakers4/silero-vad', model='silero_vad', trust_repo=True)
(get_speech_timestamps, _, read_audio, _, _) = utils

# Whisper model
whisper_model = whisper.load_model("base")

# TTS model (italiano)
tts = TTS(model_name="tts_models/it/mai_female/glow-tts", progress_bar=False, gpu=False)

# Registra 5 secondi di audio (puoi personalizzare)
print("🎤 Parla ora (5 secondi)...")
duration = 5
fs = 16000
recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='float32')
sd.wait()

# Salva in WAV temporaneo
torchaudio.save("input.wav", torch.tensor(recording.T), sample_rate=fs)

# VAD: controlla se c'è parlato
audio = read_audio("input.wav", sampling_rate=fs)
speech_parts = get_speech_timestamps(audio, model_vad, sampling_rate=fs)

if not speech_parts:
    print("🕵️ Nessuna voce rilevata.")
else:
    print("✅ Voce rilevata. Trascrivo...")
    result = whisper_model.transcribe("input.wav", language="it")
    testo_utente = result["text"]
    print("🗣️ Hai detto:", testo_utente)

    # Qui puoi simulare una risposta dell’AI o collegarla a LM Studio
    risposta_ai = f"Hai detto: {testo_utente}. Ma come mai lo hai detto proprio adesso?"

    print("🤖 Risposta:", risposta_ai)
    tts.tts_to_file(text=risposta_ai, file_path="risposta.wav")

    # Riproduci (usa un player esterno o Python lib come playsound)
    import os
    import platform
    if platform.system() == "Windows":
        os.system("start risposta.wav")
    elif platform.system() == "Darwin":  # macOS
        os.system("afplay risposta.wav")
    else:  # Linux e altri
        os.system("aplay risposta.wav")

